# OpenCodeRAG

Local-first RAG plugin for OpenCode — semantic code search powered by
embeddings and vector similarity.

## Features

- **AST-aware chunking** — splits code into functions, classes, methods using
  tree-sitter (22 languages supported). Falls back to line-based chunking for
  unrecognized formats.
- **Pluggable chunkers** — add custom language chunkers via config or programmatic API.
- **Configurable embeddings** — Ollama (default) or OpenAI-compatible providers.
  Batch embedding with configurable batch size.
- **Local vector store** — LanceDB with L2 distance scoring, memory mode for
  testing.
- **CLI** — index, query, clear, status commands.
- **OpenCode plugin** — chat.message hook injects relevant code context into
  prompts.

## Architecture

```
Workspace Files
       │
       ▼
┌──────────────┐
│   Chunker    │  AST-based (tree-sitter) or line-based fallback
└──────┬───────┘
       │ chunks
       ▼
┌──────────────┐
│   Embedder   │  Ollama / OpenAI-compatible API
└──────┬───────┘
       │ vectors
       ▼
┌──────────────┐
│  VectorStore │  LanceDB (local files or memory:// for tests)
└──────┬───────┘
       │
       ▼
┌──────────────┐
│   Retriever  │  embed → search → score → return
└──────┬───────┘
       │ results
       ▼
   LLM Context
```

## Tech Stack

| Layer       | Technology                                          |
| ----------- | --------------------------------------------------- |
| Runtime     | Node.js v22 + tsx (ESM)                             |
| Language    | TypeScript 5.8                                      |
| Chunking    | web-tree-sitter (WASM) + tree-sitter-wasm grammars  |
| Embeddings  | Ollama / OpenAI-compatible (native fetch)           |
| Vector DB   | LanceDB (`@lancedb/lancedb`)                        |
| CLI         | commander                                           |
| Tests       | Node built-in test runner (`node --test`)           |
| Package mgr | npm (with `--legacy-peer-deps`)                     |

## Installation

```bash
git clone <repo-url>
cd OpenCodeRAG
npm install --legacy-peer-deps
```

### Dependencies

- **Node.js v22+** for native ESM and fetch support
- **apache-arrow** — peer dependency for LanceDB (auto-installed)
- **tree-sitter-wasm** — ships pre-built WASM grammars for all supported languages

## Configuration

Create `opencode-rag.json` in the project root (auto-detected) or pass via
`--config`.

```json
{
  "embedding": {
    "provider": "ollama",
    "baseUrl": "http://localhost:11434/v1",
    "apiKey": null,
    "model": "nomic-embed-text"
  },
  "indexing": {
    "includeExtensions": [".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".py", ".java", ".go", ".c", ".h", ".cpp", ".cc", ".cxx", ".hpp", ".hxx", ".cs", ".json", ".md", ".mdx", ".razor", ".cshtml"],
    "excludeDirs": ["node_modules", ".git", "dist", "build", "__pycache__", ".venv"],
    "chunkOverlap": 0
  },
  "vectorStore": {
    "path": "./.opencode/rag_db"
  },
  "retrieval": {
    "topK": 10
  },
  "openCode": {
    "enabled": true,
    "maxContextChunks": 5
  },
  "chunkers": []
}
```

Config files support partial overrides — missing keys fall back to defaults
(shown above). Deep merging is applied per section.

### Embedding Providers

| Provider | `baseUrl` example                 | Notes                        |
| -------- | --------------------------------- | ---------------------------- |
| ollama   | `http://localhost:11434/api`       | Default. No apiKey required. |
| openai   | `https://api.openai.com/v1`       | Requires apiKey.             |

OpenAI provider sends all texts in a single request. Ollama sends one request
per text (Ollama `/embeddings` endpoint does not accept arrays).

## Usage

### CLI

```bash
# Index the workspace
npx tsx src/cli.ts index

# Force full re-index (clears existing data first)
npx tsx src/cli.ts index --force

# Semantic search
npx tsx src/cli.ts query "How is authentication handled?"

# Limit results
npx tsx src/cli.ts query "error handling" --top-k 5

# Show indexing stats
npx tsx src/cli.ts status

# Clear all indexed data
npx tsx src/cli.ts clear

# Use custom config
npx tsx src/cli.ts index --config ./my-config.json
```

### OpenCode Plugin

The plugin hooks into the `chat.message` pipeline:
1. Extracts the user's message from chat parts
2. Runs the retriever with the message as query
3. Formats top results as code blocks with file path and line numbers
4. Injects formatted context as a text part before LLM processing

Errors during retrieval are silently caught — a failed search won't break the
chat.

#### Install from source

After cloning and installing dependencies:

```bash
# Option 1: Copy the plugin file directly (no build needed)
copy src\plugin.ts .opencode\plugins\rag-plugin.ts

# Option 2: Build and install via npm pack
npm run build
npm pack
opencode plugin .\opencode-rag-0.1.0.tgz

# Option 3: Install from npm (once published)
opencode plugin opencode-rag
```

The plugin auto-detects configuration from `opencode-rag.json` or
`.opencode/rag.json` in the project root.

## Data Model

```typescript
interface Chunk {
  id: string;
  content: string;
  embedding?: number[];
  metadata: {
    filePath: string;
    startLine: number;
    endLine: number;
    language: string;
  };
}

interface SearchResult {
  chunk: Chunk;
  score: number;   // 1 / (1 + L2_distance), range [0, 1]
}
```

## Chunking

| Language   | Strategy                       | Captures                                  |
| ---------- | ------------------------------ | ----------------------------------------- |
| TypeScript | AST (tree-sitter)              | functions, methods, classes, interfaces   |
| Python     | AST (tree-sitter)              | functions, classes, decorated definitions |
| Java       | AST (tree-sitter)              | methods, classes, interfaces, enums       |
| Go         | AST (tree-sitter)              | functions, methods, type declarations     |
| C          | AST (tree-sitter)              | functions, structs, enums, unions, typedefs |
| C++        | AST (tree-sitter)              | functions, classes, structs, enums, namespaces, templates |
| C#         | AST (tree-sitter)              | classes, interfaces, structs, enums, methods, namespaces, records |
| JavaScript | AST (tree-sitter)              | functions, classes, arrow functions, exports |
| JSON       | AST (tree-sitter)              | key-value pairs                           |
| XML        | AST (tree-sitter)              | elements (1 chunk per root element)       |
| HTML       | AST (tree-sitter)              | `<script>` / `<style>` blocks             |
| CSS        | AST (tree-sitter)              | rule sets, at-rules, media, keyframes     |
| Razor      | Regex (brace matching)         | `@code` / `@functions` blocks, template regions |
| Markdown   | Regex heading split            | h1/h2 sections + trailing content         |
| Solution   | Regex (section boundary)       | project entries and global sections       |
| (other)    | Line-based (100 lines/chunk)   | raw text blocks                           |

AST chunking walks the tree to depth 10, collecting nodes of configured types.
Web-tree-sitter runs as WASM — no native build tools required.

## Pluggable Chunkers

Custom chunkers can be added without modifying the project source code. Two
registration paths are supported:

### Config file

Add a `chunkers` array to `opencode-rag.json`:

```json
{
  "chunkers": [
    { "module": "./path/to/rust-chunker.js", "extensions": [".rs"] }
  ]
}
```

The module path is resolved relative to the config file. The loaded module must
export (as default or named) an object implementing the `Chunker` interface:

```typescript
interface Chunker {
  readonly language: string;
  readonly fileExtensions?: string[];
  chunk(filePath: string, content: string): Promise<Chunk[]>;
}
```

### Programmatic

```typescript
import { registerChunker } from "opencode-rag";
registerChunker(myChunker, [".rs"]);
```

The optional second argument overrides the chunker's `fileExtensions`. If a
built-in chunker already covers the requested extension, the new registration is
skipped and a warning is emitted.

## Vector Store

LanceDB stores chunks in a `chunks` table with columns: `id`, `content`,
`embedding` (vector), `filePath`, `startLine`, `endLine`, `language`.

- **Disk mode**: files in `vectorStore.path` (default `.opencode/rag_db`)
- **Memory mode**: `memory://` URI — for tests only, data lost on close
- Schema is auto-inferred from a seed row on first table creation
- L2 distance search, score = `1 / (1 + distance)`

## Development

```bash
# TypeScript typecheck
npm run typecheck

# Run all tests
npm test

# Run specific test file
node --import tsx --test src/__tests__/chunker/fallback.test.ts
```

Project structure:
```
src/
  core/          — interfaces.ts, config.ts
  chunker/       — grammar.ts, base.ts, language chunkers, fallback.ts, factory.ts, loader.ts
  embedder/      — ollama.ts, openai.ts, factory.ts
  vectorstore/   — lancedb.ts
  retriever/     — retriever.ts
  types/         — opencode-plugin.d.ts
  cli.ts, plugin.ts, index.ts
  __tests__/     — mirrors the module structure
```

Test framework is Node's built-in runner (`node:test`) with `tsx` for TypeScript
imports. No test library dependencies.

## Limitations

- No incremental indexing — re-indexes full workspace each time
- Embedding model must support 384-dimensional vectors (default seed row size)
- 12 built-in chunkers (AST for 10 languages, regex for 2) + configurable fallback

## Privacy

All processing is local. Embeddings are generated via local Ollama by default.
No data leaves the machine unless configured to use a remote embedding API.
